 class Edge {
	        int source;
	        String destination;
	        int weight;

	        public Edge(int origin, String destination2, double d) {
	            this.source = origin;
	            this.destination = destination2;
	            this.weight = (int) d;
	        }

			
		
	    }
