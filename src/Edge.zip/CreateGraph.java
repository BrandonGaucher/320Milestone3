import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CreateGraph {
	 public static Graph createGraph(int numAirports) throws IOException{
			
		 
		Graph g = new Graph(numAirports);
		
			try {
			FileInputStream fis = new FileInputStream("./data/data.xlsx");
			Workbook workbook = new XSSFWorkbook(fis);
			Sheet sheet = workbook.getSheetAt(0);
			int lastRowNum = sheet.getLastRowNum();
			

			
			for(int i=0; i<=lastRowNum; i++) {
				Row row = sheet.getRow(i);
				
				Cell originKey = row.getCell(0);
				int origin = (int) originKey.getNumericCellValue();
				
				Cell destKey= row.getCell(1);
				String destination = destKey.getStringCellValue().trim();
				
				Cell priceKey = row.getCell(2);
				double price = priceKey.getNumericCellValue();
				double cost = (price*1200)*(price*1200);
				
				Cell timeKey = row.getCell(3);
				double time = timeKey.getNumericCellValue()/65;
				
				
				g.addEdge(origin, destination, cost*time);
		
		}
				
		}catch(FileNotFoundException e){
			e.printStackTrace();
			
		}
			return g;
		
			}
	

}
